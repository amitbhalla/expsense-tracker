// Custom JavaScript for Expense Tracker

document.addEventListener('DOMContentLoaded', function() {
    // Handle card animations
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.classList.add('slide-in');
    });
    
    // Enable tooltips everywhere
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.forEach(function(tooltipTriggerEl) {
        new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-warning)');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Highlight active nav item
    const currentLocation = window.location.pathname;
    const navLinks = document.querySelectorAll('.sidebar a');
    
    navLinks.forEach(link => {
        const linkPath = link.getAttribute('href');
        if (currentLocation.includes(linkPath) && linkPath !== '/') {
            link.classList.add('active');
        } else if (currentLocation === '/' && linkPath === '/') {
            link.classList.add('active');
        }
    });
    
    // Add confirm dialog to delete buttons
    const deleteButtons = document.querySelectorAll('a[href*="delete"]');
    deleteButtons.forEach(button => {
        if (!button.getAttribute('data-bs-toggle')) {
            button.addEventListener('click', function(e) {
                if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                    e.preventDefault();
                }
            });
        }
    });
    
    // Toggle transaction type specific fields
    const transactionTypeSelect = document.getElementById('id_transaction_type');
    if (transactionTypeSelect) {
        const toggleFields = function() {
            const selectedValue = transactionTypeSelect.value;
            const toAccountField = document.getElementById('div_id_to_account');
            
            if (toAccountField) {
                if (selectedValue === 'TRANSFER') {
                    toAccountField.style.display = 'block';
                } else {
                    toAccountField.style.display = 'none';
                }
            }
        };
        
        // Initial toggle
        toggleFields();
        
        // Add event listener
        transactionTypeSelect.addEventListener('change', toggleFields);
    }
    
    // Date range picker functionality for dashboard
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    
    if (startDateInput && endDateInput) {
        // Set default date range if not already set
        if (!startDateInput.value) {
            const today = new Date();
            const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
            startDateInput.valueAsDate = firstDayOfMonth;
            endDateInput.valueAsDate = today;
        }
        
        // Ensure end date is not before start date
        startDateInput.addEventListener('change', function() {
            if (endDateInput.value && startDateInput.value > endDateInput.value) {
                endDateInput.value = startDateInput.value;
            }
        });
        
        endDateInput.addEventListener('change', function() {
            if (startDateInput.value && endDateInput.value < startDateInput.value) {
                startDateInput.value = endDateInput.value;
            }
        });
    }
});