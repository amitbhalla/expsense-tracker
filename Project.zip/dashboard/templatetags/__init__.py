# Init file for templatetags package
